var eamount,disco,tamount;

function dispval() {
    
    var electitem = document.getElementById("Eitem");  
    eamount = document.getElementById("price").value = electitem.options[electitem.selectedIndex].value; 
        
  }
  function check(disc) {
    if(disc==0){
      disco=eamount
      document.getElementById("tprice").value=disco;
    }
    else{

   disco =disc*eamount;
   document.getElementById("tprice").value=disco;
    }
  }
  function myFunction() {
    var x = document.getElementById("inprice").value;
    tamount=x-disco;

    if(x=="0")
    {
      alert("Invalid Input, Please try again");
      
    }
    else
    {
    alert("Transaction Complete,\n\n\n your balance is "+tamount);
    }
    ///document.getElementById("demo").innerHTML = x;
  }
